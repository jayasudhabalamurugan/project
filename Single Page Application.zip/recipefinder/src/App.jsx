// src/App.jsx
import React, { useMemo, useState, useEffect } from "react";
import { useRecipes } from "./context/RecipeContext";
import Header from "./components/Header";
import RecipeCard from "./components/RecipeCard";
import RecipeDetail from "./components/RecipeDetail";
import AddRecipe from "./components/AddRecipe";

export default function App() {
  const { recipes, addRecipe, toggleLike } = useRecipes();
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState(null);
  const [activeId, setActiveId] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [filter, setFilter] = useState("all");
  const { isSaved } = useRecipes(); // get isSaved function

  // compute favorites count
  const favCount = useMemo(() => {
    try {
      return recipes.filter(r => isSaved(r.id)).length;
    } catch (e) {
      return 0;
    }
  }, [recipes, isSaved]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return recipes.filter(r => {
      if (filter === "veg" && r.diet !== "vegetarian") return false;
      if (filter === "nonveg" && r.diet !== "non-veg") return false;
      if (filter === "favorites" && !isSaved(r.id)) return false;
      if (!s) return true;
      return (r.title || "").toLowerCase().includes(s) || (r.ingredients || []).some(i => (i + "").toLowerCase().includes(s));
    });
  }, [recipes, q, filter, isSaved]);

  // listen to window custom events for like/share/save (existing logic)
  useEffect(() => {
    function onLike(e) { toggleLike(e.detail, "me"); }
    function onShare(e) { /* existing share handler or no-op */ }
    function onSave(e) { /* optional: nothing here since isSaved reads localStorage */ }

    window.addEventListener("recipe-like", onLike);
    window.addEventListener("recipe-share", onShare);
    window.addEventListener("recipe-save", onSave);
    return () => {
      window.removeEventListener("recipe-like", onLike);
      window.removeEventListener("recipe-share", onShare);
      window.removeEventListener("recipe-save", onSave);
    };
  }, [toggleLike]);

  return (
    <>
      <Header q={q} setQ={setQ} onOpenAdd={() => setShowAdd(true)} filter={filter} setFilter={setFilter} favCount={favCount} />

      <main style={{ maxWidth: 1100, margin: "12px auto", padding: "0 16px" }}>
        <p style={{ color: "#666" }}>Click image to open details. Double-tap image or press Like to ❤️</p>

        <div className={`recipe-grid ${activeId ? "dim" : ""}`}>
          {filtered.map(r => (
            <RecipeCard
              key={r.id}
              recipe={r}
              isActive={activeId === r.id}
              setActive={(v) => {
                if (typeof v === "function") setActiveId(prev => v(prev));
                else setActiveId(prev => prev === v ? null : v);
              }}
              onOpen={(rec) => setSelected(rec)}
            />
          ))}
        </div>
      </main>

      {selected && <RecipeDetail recipe={selected} onClose={() => setSelected(null)} />}
      {showAdd && <AddRecipe onClose={() => setShowAdd(false)} onAdd={(r) => addRecipe(r)} />}
    </>
  );
}
