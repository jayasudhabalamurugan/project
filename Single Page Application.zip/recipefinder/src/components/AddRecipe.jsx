// src/components/AddRecipe.jsx
import React, { useState } from "react";

export default function AddRecipe({ onClose, onAdd }) {
  const [title, setTitle] = useState("");
  const [cookTime, setCookTime] = useState("");
  const [servings, setServings] = useState(2);
  const [ingredients, setIngredients] = useState("");
  const [steps, setSteps] = useState("");
  const [diet, setDiet] = useState("vegetarian");
  const [imageData, setImageData] = useState("");

  function handleFile(e) {
    const f = e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onloadend = () => setImageData(reader.result.toString());
    reader.readAsDataURL(f);
  }

  function submit(e) {
    e.preventDefault();
    if (!title.trim()) { alert("Add a title"); return; }
    const newRecipe = {
      title: title.trim(),
      image: imageData || "https://source.unsplash.com/800x600/?food",
      cookTimeMins: Number(cookTime) || 20,
      servings: Number(servings) || 2,
      ingredients: ingredients.split("\n").map(s => s.trim()).filter(Boolean),
      steps: steps.split("\n").map(s => s.trim()).filter(Boolean),
      diet,
    };
    onAdd(newRecipe);
    onClose();
  }

  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal-content" onClick={(e)=>e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>✕</button>
        <h3>Add New Recipe</h3>

        <form onSubmit={submit}>
          <label>Title</label>
          <input value={title} onChange={(e)=>setTitle(e.target.value)} required />

          <label>Cook Time (mins)</label>
          <input value={cookTime} onChange={(e)=>setCookTime(e.target.value)} type="number" />

          <label>Servings</label>
          <input value={servings} onChange={(e)=>setServings(e.target.value)} type="number" />

          <label>Diet</label>
          <select value={diet} onChange={(e)=>setDiet(e.target.value)}>
            <option value="vegetarian">Vegetarian</option>
            <option value="non-veg">Non-Veg</option>
            <option value="vegan">Vegan</option>
          </select>

          <label>Ingredients (one per line)</label>
          <textarea value={ingredients} onChange={(e)=>setIngredients(e.target.value)} rows={4} />

          <label>Steps (one per line)</label>
          <textarea value={steps} onChange={(e)=>setSteps(e.target.value)} rows={4} />

          <label>Image (optional)</label>
          <input type="file" accept="image/*" onChange={handleFile} />
          {imageData && <img src={imageData} alt="preview" style={{ width: 160, borderRadius: 8, marginTop: 8 }} />}

          <div style={{ marginTop: 12, textAlign: "right" }}>
            <button type="button" className="btn btn-outline" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-cta" style={{ marginLeft: 8 }}>Add</button>
          </div>
        </form>
      </div>
    </div>
  );
}
