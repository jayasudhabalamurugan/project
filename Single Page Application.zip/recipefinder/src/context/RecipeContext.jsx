// src/context/RecipeContext.jsx
import React, { createContext, useContext, useEffect, useState } from "react";
import sampleRecipesDefault from "../data/sampleRecipes";

const RecipeCtx = createContext();
const REC_KEY = "recipefinder_recipes_v4";
const SAVED_KEY = "recipefinder_saved_v1";

export function RecipeProvider({ children }) {
  const [recipes, setRecipes] = useState(() => {
    try {
      const raw = localStorage.getItem(REC_KEY);
      return raw ? JSON.parse(raw) : sampleRecipesDefault;
    } catch (e) {
      return sampleRecipesDefault;
    }
  });

  useEffect(() => {
    localStorage.setItem(REC_KEY, JSON.stringify(recipes));
  }, [recipes]);

  function addRecipe(recipe) {
    const newR = {
      id: Date.now().toString(),
      likes: [],
      shares: 0,
      createdAt: new Date().toISOString(),
      ...recipe
    };
    setRecipes((p) => [newR, ...p]);
  }

  function toggleLike(id, userId = "me") {
    setRecipes((p) =>
      p.map((r) => {
        if (r.id !== id) return r;
        const has = Array.isArray(r.likes) && r.likes.includes(userId);
        return { ...r, likes: has ? r.likes.filter((x) => x !== userId) : [...(r.likes || []), userId] };
      })
    );
  }

  function toggleSave(id) {
    const raw = localStorage.getItem(SAVED_KEY);
    const saved = raw ? JSON.parse(raw) : [];
    const newSaved = saved.includes(id) ? saved.filter((x) => x !== id) : [...saved, id];
    localStorage.setItem(SAVED_KEY, JSON.stringify(newSaved));
  }

  function isSaved(id) {
    const raw = localStorage.getItem(SAVED_KEY);
    const saved = raw ? JSON.parse(raw) : [];
    return saved.includes(id);
  }

  function incrementShare(id) {
    setRecipes((p) => p.map((r) => (r.id === id ? { ...r, shares: (r.shares || 0) + 1 } : r)));
  }

  return (
    <RecipeCtx.Provider value={{ recipes, addRecipe, toggleLike, toggleSave, isSaved, incrementShare }}>
      {children}
    </RecipeCtx.Provider>
  );
}

export const useRecipes = () => useContext(RecipeCtx);
